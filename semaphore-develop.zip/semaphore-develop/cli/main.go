package main

import (
	"github.com/ansible-semaphore/semaphore/cli/cmd"
)

func main() {
	cmd.Execute()
}
