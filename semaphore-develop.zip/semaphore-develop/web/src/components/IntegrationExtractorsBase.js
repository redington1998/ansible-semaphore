export default {
  props: {
    // integrationId: Number,
    projectId: Number,
  },
};
