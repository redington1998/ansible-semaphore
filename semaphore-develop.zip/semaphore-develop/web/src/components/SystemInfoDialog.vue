<template>
  <v-dialog></v-dialog>
</template>
<script>
export default {

};
</script>
