import Vue from 'vue';
import i18n from '@/plugins/i18';

export default new Vue(i18n);
