alter table `project__repository` add git_branch varchar(255) not null default '';
