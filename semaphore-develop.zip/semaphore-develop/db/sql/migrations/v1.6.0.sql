alter table project__environment add `removed` boolean default false;
alter table project__inventory add `removed` boolean default false;
alter table project__repository add `removed` boolean default false;
alter table access_key add `removed` boolean default false;
