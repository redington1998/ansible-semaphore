alter table project__environment add `name` varchar(255);
alter table project__inventory add `name` varchar(255);
alter table project__repository add `name` varchar(255);
