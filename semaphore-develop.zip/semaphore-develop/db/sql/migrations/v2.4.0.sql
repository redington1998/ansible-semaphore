ALTER TABLE project ADD alert_chat varchar(10) DEFAULT '';
