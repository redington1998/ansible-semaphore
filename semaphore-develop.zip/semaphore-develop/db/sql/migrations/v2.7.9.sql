alter table `project__template` add `description` longtext;
alter table `project__template` add `removed` boolean not null default false;