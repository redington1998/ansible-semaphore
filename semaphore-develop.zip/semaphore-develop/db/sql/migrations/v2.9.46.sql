ALTER TABLE project__template ADD `app` varchar(50) NOT NULL DEFAULT '';
