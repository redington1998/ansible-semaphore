ALTER TABLE task ADD dry_run boolean NOT NULL DEFAULT false;
