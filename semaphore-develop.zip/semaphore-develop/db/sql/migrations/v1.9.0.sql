ALTER TABLE project__template ADD alias varchar(100);
